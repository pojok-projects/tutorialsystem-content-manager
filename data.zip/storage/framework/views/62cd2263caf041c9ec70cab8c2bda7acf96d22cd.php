<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
</head>

<body>

    <form action="/input/data" method="post">

        Nama :
        <input type="text" name="nama"> <br />
        Alamat :
        <input type="text" name="alamat"> <br />
        <input type="submit" value="Simpan">
    </form>

</body>

</html><?php /**PATH C:\xampp\htdocs\rest-api\resources\views/input/index.blade.php ENDPATH**/ ?>