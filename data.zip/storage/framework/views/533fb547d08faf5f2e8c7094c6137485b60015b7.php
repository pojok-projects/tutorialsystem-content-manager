<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="/category/data" method="post">
        <input type="text" name="data"> <input type="submit" value="submit">
    </form>
</body>

</html><?php /**PATH C:\xampp\htdocs\rest-api\resources\views/category/list.blade.php ENDPATH**/ ?>